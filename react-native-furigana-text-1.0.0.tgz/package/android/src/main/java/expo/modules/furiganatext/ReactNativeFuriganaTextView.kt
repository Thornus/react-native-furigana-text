package expo.modules.furiganatext

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.StaticLayout
import android.text.TextPaint
import android.text.style.ReplacementSpan
import android.util.AttributeSet
import android.view.View

class ReactNativeFuriganaTextView @JvmOverloads constructor(
  context: Context,
  attrs: AttributeSet? = null,
  defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {
  
  private var _text: String = ""
  private var _furigana: Map<String, String> = emptyMap()
  private var _textPaint: TextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
    color = Color.BLACK
    textSize = 16f
  }
  private var _furiganaPaint: TextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
    color = Color.GRAY
    textSize = 8f
  }
  
  fun setText(text: String) {
    _text = text
    invalidate()
  }
  
  fun setFurigana(furigana: Map<String, String>) {
    _furigana = furigana
    invalidate()
  }
  
  fun setTextSize(size: Float) {
    _textPaint.textSize = size
    invalidate()
  }
  
  fun setTextColor(color: Int) {
    _textPaint.color = color
    invalidate()
  }
  
  fun setFuriganaTextSize(size: Float) {
    _furiganaPaint.textSize = size
    invalidate()
  }
  
  fun setFuriganaTextColor(color: Int) {
    _furiganaPaint.color = color
    invalidate()
  }
  
  override fun onDraw(canvas: Canvas) {
    super.onDraw(canvas)
    
    if (_text.isEmpty()) return
    
    // Create spannable string with ruby annotations
    val spannableStringBuilder = SpannableStringBuilder(_text)
    
    // Apply furigana spans
    for ((kanji, reading) in _furigana) {
      val startIndex = _text.indexOf(kanji)
      if (startIndex != -1) {
        val endIndex = startIndex + kanji.length
        val rubySpan = RubySpan(kanji, reading, _textPaint, _furiganaPaint)
        spannableStringBuilder.setSpan(
          rubySpan,
          startIndex,
          endIndex,
          SpannableStringBuilder.SPAN_EXCLUSIVE_EXCLUSIVE
        )
      }
    }
    
    // Create and draw layout
    val staticLayout = StaticLayout.Builder.obtain(
      spannableStringBuilder,
      0,
      spannableStringBuilder.length,
      _textPaint,
      width
    ).build()
    
    staticLayout.draw(canvas)
  }
  
  inner class RubySpan(
    private val kanji: String,
    private val reading: String,
    private val textPaint: TextPaint,
    private val furiganaPaint: TextPaint
  ) : ReplacementSpan() {
    
    override fun getSize(
      paint: Paint,
      text: CharSequence,
      start: Int,
      end: Int,
      fm: Paint.FontMetricsInt?
    ): Int {
      // Return width of the kanji
      return textPaint.measureText(kanji).toInt()
    }
    
    override fun draw(
      canvas: Canvas,
      text: CharSequence,
      start: Int,
      end: Int,
      x: Float,
      top: Int,
      y: Int,
      bottom: Int,
      paint: Paint
    ) {
      // Draw the kanji
      canvas.drawText(kanji, x, y.toFloat(), textPaint)
      
      // Draw furigana above kanji
      val furiganaWidth = furiganaPaint.measureText(reading)
      val furiganaX = x + (textPaint.measureText(kanji) - furiganaWidth) / 2
      val furiganaY = top + furiganaPaint.textSize
      
      canvas.drawText(reading, furiganaX, furiganaY, furiganaPaint)
    }
  }
}