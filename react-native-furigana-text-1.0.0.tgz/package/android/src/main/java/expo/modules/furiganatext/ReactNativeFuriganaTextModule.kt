package expo.modules.furiganatext

import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class ReactNativeFuriganaTextModule : Module() {
  override fun definition() = ModuleDefinition {
    Name("ReactNativeFuriganaText")
    
    View(ReactNativeFuriganaTextView::class) {
      Prop("text") { view, text ->
        view.text = text
      }
      
      Prop("furigana") { view, furigana ->
        view.setFurigana(furigana)
      }
      
      Prop("fontSize") { view, fontSize ->
        view.setTextSize(fontSize.toFloat())
      }
      
      Prop("color") { view, color ->
        view.setTextColor(android.graphics.Color.parseColor(color))
      }
      
      Prop("furiganaFontSize") { view, fontSize ->
        view.setFuriganaTextSize(fontSize.toFloat())
      }
      
      Prop("furiganaColor") { view, color ->
        view.setFuriganaTextColor(android.graphics.Color.parseColor(color))
      }
    }
  }
}