import { NativeModule, requireNativeModule } from 'expo';

declare class ReactNativeFuriganaTextModule extends NativeModule<{}> {}

export default requireNativeModule<ReactNativeFuriganaTextModule>('ReactNativeFuriganaText');
