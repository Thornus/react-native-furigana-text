import React from 'react';
import { View, Text, StyleSheet, Platform } from 'react-native';
import { requireNativeViewManager } from 'expo-modules-core';

import { FuriganaTextProps } from './ReactNativeFuriganaText.types';
import { parseFuriganaText } from './utils';

interface NativeFuriganaTextProps {
  style?: any;
  text: string;
  furigana: { [kanji: string]: string };
  fontSize: number;
  color: string;
  furiganaFontSize: number;
  furiganaColor: string;
  selectable: boolean;
  numberOfLines?: number;
}

const ReactNativeFuriganaText =
  requireNativeViewManager<NativeFuriganaTextProps>('ReactNativeFuriganaText');

export function FuriganaText({
  text,
  style,
  fontSize = 16,
  color = '#000',
  furiganaFontSize,
  furiganaColor = '#666',
  onPress,
  selectable = false,
  numberOfLines,
}: FuriganaTextProps) {
  // Parse furigana syntax
  const { baseText, furiganaMap } = parseFuriganaText(text);

  // Calculate furigana font size if not provided
  const calculatedFuriganaSize = furiganaFontSize || fontSize * 0.5;

  // Platform-specific rendering
  const renderNative = () => (
    <ReactNativeFuriganaText
      style={style}
      text={baseText}
      furigana={furiganaMap}
      fontSize={fontSize}
      color={color}
      furiganaFontSize={calculatedFuriganaSize}
      furiganaColor={furiganaColor}
      selectable={selectable}
      numberOfLines={numberOfLines}
    />
  );

  const renderWeb = () => (
    <View style={[styles.container, style]}>
      <Text style={[styles.text, { fontSize, color }]}>
        {baseText.split(/([一-龯々])/g).map((segment, index) => {
          if (furiganaMap[segment]) {
            return (
              <Text key={index} style={styles.kanjiContainer}>
                <Text style={styles.furigana}>{furiganaMap[segment]}</Text>
                <Text>{segment}</Text>
              </Text>
            );
          }
          return segment;
        })}
      </Text>
    </View>
  );

  return Platform.OS === 'web' ? renderWeb() : renderNative();
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignItems: 'flex-end',
  },
  text: {
    fontSize: 16,
    lineHeight: 24,
  },
  kanjiContainer: {
    flexDirection: 'column',
    alignItems: 'center',
  },
  furigana: {
    fontSize: 8,
    color: '#666',
    marginBottom: 2,
  },
});
