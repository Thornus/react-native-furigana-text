import { ParsedFurigana, TextSegment } from './ReactNativeFuriganaText.types';

export function parseFuriganaText(text: string): ParsedFurigana {
  const furiganaMap: { [kanji: string]: string } = {};
  const baseText = text.replace(/\[([^\]]+)\]/g, (match, reading) => {
    // Extract kanji before bracket
    const beforeBracket = text.substring(0, text.indexOf(match));
    const kanjiMatch = beforeBracket.match(/([一-龯々])/g);
    if (kanjiMatch && kanjiMatch.length > 0) {
      const kanji = kanjiMatch[kanjiMatch.length - 1];
      furiganaMap[kanji] = reading;
      return kanji; // Replace [reading] with just the kanji
    }
    return match;
  });

  return {
    baseText,
    furiganaMap,
  };
}

export function extractTextSegments(text: string): TextSegment[] {
  const segments: TextSegment[] = [];
  const regex = /([一-龯々])(\[([^\]]+)\])?/g;
  let match;

  while ((match = regex.exec(text)) !== null) {
    const [, kanji, , furigana] = match;

    if (furigana) {
      segments.push({
        type: 'kanji',
        value: kanji,
        furigana,
      });
    } else {
      segments.push({
        type: 'text',
        value: kanji,
      });
    }
  }

  return segments;
}
