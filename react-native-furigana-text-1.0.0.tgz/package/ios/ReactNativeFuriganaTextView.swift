import ExpoModulesCore
import UIKit
import CoreText

class ReactNativeFuriganaTextView: ExpoView {
  var text: String = "" {
    didSet { setNeedsDisplay() }
  }

  var furigana: [String: String] = [:] {
    didSet { setNeedsDisplay() }
  }

  var fontSize: CGFloat = 16 {
    didSet { setNeedsDisplay() }
  }

  var textColor: UIColor = .black {
    didSet { setNeedsDisplay() }
  }

  var furiganaFontSize: CGFloat = 8 {
    didSet { setNeedsDisplay() }
  }

  var furiganaColor: UIColor = .gray {
    didSet { setNeedsDisplay() }
  }

  required init(appContext: AppContext? = nil) {
    super.init(appContext: appContext)
    isOpaque = false
    backgroundColor = .clear
  }

  override func draw(_ rect: CGRect) {
    guard let context = UIGraphicsGetCurrentContext() else { return }

    let attributedString = createAttributedString()

    context.textMatrix = .identity
    context.translateBy(x: 0, y: bounds.height)
    context.scaleBy(x: 1.0, y: -1.0)

    let framesetter = CTFramesetterCreateWithAttributedString(attributedString)
    let path = CGPath(rect: bounds, transform: nil)
    let frame = CTFramesetterCreateFrame(framesetter, CFRange(location: 0, length: attributedString.length), path, nil)

    CTFrameDraw(frame, context)
  }

  override func sizeThatFits(_ size: CGSize) -> CGSize {
    let attributedString = createAttributedString()
    let framesetter = CTFramesetterCreateWithAttributedString(attributedString)
    let constrainSize = CGSize(width: size.width, height: CGFloat.greatestFiniteMagnitude)
    let fittedSize = CTFramesetterSuggestFrameSizeWithConstraints(
      framesetter,
      CFRange(location: 0, length: attributedString.length),
      nil,
      constrainSize,
      nil
    )
    return CGSize(width: ceil(fittedSize.width), height: ceil(fittedSize.height))
  }

  private func createAttributedString() -> NSAttributedString {
    let attributedString = NSMutableAttributedString(string: text)

    let baseFont = UIFont.systemFont(ofSize: fontSize)
    let fullRange = NSRange(location: 0, length: (text as NSString).length)
    attributedString.addAttribute(.font, value: baseFont, range: fullRange)
    attributedString.addAttribute(.foregroundColor, value: textColor, range: fullRange)

    let rubyFont = UIFont.systemFont(ofSize: furiganaFontSize)
    let rubyAttributes: [CFString: Any] = [
      kCTFontAttributeName: rubyFont,
      kCTForegroundColorAttributeName: furiganaColor.cgColor
    ]
    let rubyAttributesCF = rubyAttributes as CFDictionary

    for (kanji, reading) in furigana {
      let range = (text as NSString).range(of: kanji)
      if range.location != NSNotFound {
        let rubyAnnotation = CTRubyAnnotationCreateWithAttributes(
          CTRubyAlignment.auto,
          CTRubyOverhang.auto,
          CTRubyPosition.before,
          reading as CFString,
          rubyAttributesCF
        )

        attributedString.addAttribute(
          NSAttributedString.Key(kCTRubyAnnotationAttributeName as String),
          value: rubyAnnotation,
          range: range
        )
      }
    }

    return attributedString
  }
}